(function () {
  "use strict";
  var PHONE = "(302) 279-2886", TEL = "tel:+13022792886";
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  var root = document.documentElement;

  /* ---------- mobile menu + dropdowns ---------- */
  var menuBtn = document.getElementById("menuBtn"), nav = document.getElementById("mainNav");
  if (menuBtn && nav) {
    menuBtn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }
  document.querySelectorAll(".dd-btn").forEach(function (b) {
    b.addEventListener("click", function () {
      var dd = b.parentElement, open = !dd.classList.contains("open");
      document.querySelectorAll(".dd.open").forEach(function (o) { if (o !== dd) { o.classList.remove("open"); o.querySelector(".dd-btn").setAttribute("aria-expanded", "false"); } });
      dd.classList.toggle("open", open); b.setAttribute("aria-expanded", open ? "true" : "false");
    });
  });
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".dd")) document.querySelectorAll(".dd.open").forEach(function (o) { o.classList.remove("open"); o.querySelector(".dd-btn").setAttribute("aria-expanded", "false"); });
  });

  /* ---------- phone links inside a preview frame ---------- */
  var framed = false; try { framed = window.self !== window.top; } catch (e) { framed = true; }
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest('a[href^="tel:"]');
    if (!a || !framed) return;
    e.preventDefault();
    var c = document.getElementById("contact");
    if (c) {
      c.scrollIntoView({ behavior: "smooth", block: "start" });
      var p = c.querySelector(".phone-big");
      if (p) { p.classList.remove("flash"); void p.offsetWidth; p.classList.add("flash"); }
    }
  });

  /* ---------- ZIP checker + town buttons (home) ---------- */
  var NCC = {"19801":"Wilmington","19802":"Wilmington","19803":"Wilmington (Brandywine)","19804":"Newport / Wilmington","19805":"Wilmington / Elsmere","19806":"Wilmington","19807":"Greenville / Wilmington","19808":"Pike Creek / Wilmington","19809":"Wilmington (Bellefonte)","19810":"Wilmington (North)","19850":"Wilmington","19880":"Wilmington","19884":"Wilmington","19885":"Wilmington","19886":"Wilmington","19890":"Wilmington","19891":"Wilmington","19892":"Wilmington","19893":"Wilmington","19894":"Wilmington","19895":"Wilmington","19896":"Wilmington","19897":"Wilmington","19898":"Wilmington","19899":"Wilmington","19701":"Bear","19702":"Newark / Glasgow","19703":"Claymont","19706":"Delaware City","19707":"Hockessin","19708":"Kirkwood","19709":"Middletown","19710":"Montchanin","19711":"Newark","19712":"Newark","19713":"Newark","19714":"Newark","19715":"Newark","19716":"Newark","19717":"Newark","19718":"Newark","19720":"New Castle","19721":"New Castle","19725":"Newark","19726":"New Castle","19730":"Odessa","19731":"Port Penn","19732":"Rockland","19733":"Saint Georges","19734":"Townsend","19735":"Winterthur","19736":"Yorklyn"};
  var PAGES = {"Wilmington":"wilmington","Newark":"newark","New Castle":"new-castle","Bear":"bear","Middletown":"middletown","Hockessin":"hockessin","Claymont":"claymont","Pike Creek":"pike-creek","Glasgow":"glasgow"};
  var form = document.getElementById("zipForm");
  if (form) {
    var input = document.getElementById("zip"), out = document.getElementById("zipResult"), checker = document.getElementById("checker");
    var towns = [].slice.call(document.querySelectorAll(".town"));
    var mark = function (b) { towns.forEach(function (t) { t.setAttribute("aria-pressed", t === b ? "true" : "false"); }); };
    var show = function (cls, text, town) {
      out.className = "result " + cls; out.textContent = "";
      var s = document.createElement("span"); s.textContent = text; out.appendChild(s);
      if (cls === "ok") {
        var row = document.createElement("div"); row.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";
        var a = document.createElement("a"); a.className = "btn"; a.href = TEL; a.textContent = "Call " + PHONE; row.appendChild(a);
        var key = town && Object.keys(PAGES).filter(function (k) { return town.indexOf(k) === 0; })[0];
        if (key) { var l = document.createElement("a"); l.className = "btn outline-dark"; l.href = "garage-door-repair-" + PAGES[key] + "-de.html"; l.textContent = key + " page ›"; row.appendChild(l); }
        out.appendChild(row);
      }
    };
    towns.forEach(function (b) {
      b.addEventListener("click", function () {
        mark(b); input.value = b.dataset.zip;
        show("ok", "✓ Yes, we serve " + b.dataset.town + "! Call us to book a technician.", b.dataset.town);
        checker.classList.remove("flash"); void checker.offsetWidth; checker.classList.add("flash");
        if (window.innerWidth < 900) checker.scrollIntoView({ behavior: "smooth", block: "center" });
      });
    });
    input.addEventListener("input", function () { input.value = input.value.replace(/\D/g, "").slice(0, 5); });
    form.addEventListener("submit", function (e) {
      e.preventDefault(); var z = input.value.trim();
      if (!/^\d{5}$/.test(z)) { mark(null); show("", "Enter all 5 digits of your ZIP code."); return; }
      var m = null; towns.forEach(function (t) { if (!m && t.textContent.indexOf(z) > -1) m = t; }); mark(m);
      if (NCC[z]) show("ok", "✓ Yes, we serve " + NCC[z] + " (" + z + ")! Call us to book a technician.", NCC[z]);
      else if (/^19[7-9]\d\d$/.test(z)) show("no", "✕ ZIP " + z + " is in Delaware but outside New Castle County, so we can't take this job.");
      else show("no", "✕ ZIP " + z + " is outside our service area. We work only in New Castle County, Delaware.");
    });
  }

  /* ---------- estimate form ---------- */
  document.querySelectorAll("form.estimate").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      var msg = f.querySelector(".est-msg"), bad = [];
      f.querySelectorAll("[required]").forEach(function (el) {
        var ok = el.value.trim() !== "" && (el.type !== "tel" || el.value.replace(/\D/g, "").length >= 10);
        el.classList.toggle("bad", !ok); if (!ok) bad.push(el);
      });
      if (bad.length) { msg.className = "est-msg err"; msg.textContent = "Please fill in your name, a 10-digit phone number and your town."; bad[0].focus(); return; }
      var endpoint = f.dataset.endpoint;
      if (!endpoint) {
        msg.className = "est-msg err";
        msg.textContent = "Online requests aren't connected yet. Please call " + PHONE + " and we'll book you right away.";
        return;
      }
      var data = {}; new FormData(f).forEach(function (v, k) { data[k] = v; });
      msg.className = "est-msg"; msg.textContent = "Sending…";
      fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" }, body: JSON.stringify(data) })
        .then(function (r) { if (!r.ok) throw 0; msg.className = "est-msg ok"; msg.textContent = "Thanks! We got your request and will call you back soon."; f.reset(); })
        .catch(function () { msg.className = "est-msg err"; msg.textContent = "Your request didn't go through. Please call " + PHONE + "."; });
    });
  });

  /* ---------- accessibility widget ---------- */
  var A11Y = ["contrast", "gray", "links", "font", "motion"];
  var a11yBtn = document.getElementById("a11yBtn"), panel = document.getElementById("a11yPanel"), page = document.querySelector(".page");
  var scale = parseFloat(store("egd-a11y-scale") || "1") || 1;
  function applyScale() { if (page) page.style.zoom = scale === 1 ? "" : scale; }
  function applyFlags() {
    A11Y.forEach(function (k) {
      var on = store("egd-a11y-" + k) === "1";
      root.classList.toggle("a11y-" + k, on);
      var b = panel && panel.querySelector('[data-a11y="' + k + '"]'); if (b) b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    var big = panel && panel.querySelector('[data-a11y="bigger"]'); if (big) big.setAttribute("aria-pressed", scale > 1 ? "true" : "false");
    applyScale();
  }
  if (a11yBtn && panel) {
    var toggle = function (open) { panel.hidden = !open; a11yBtn.setAttribute("aria-expanded", open ? "true" : "false"); if (open) panel.querySelector("button[data-a11y]").focus(); };
    a11yBtn.addEventListener("click", function () { toggle(panel.hidden); });
    panel.addEventListener("click", function (e) {
      if (e.target.closest("[data-a11y-close]")) { toggle(false); a11yBtn.focus(); return; }
      var b = e.target.closest("[data-a11y]"); if (!b) return;
      var k = b.dataset.a11y;
      if (k === "bigger") scale = Math.min(1.4, Math.round((scale + 0.1) * 10) / 10);
      else if (k === "smaller") scale = Math.max(0.9, Math.round((scale - 0.1) * 10) / 10);
      else if (k === "reset") { scale = 1; A11Y.forEach(function (x) { store("egd-a11y-" + x, "0"); }); }
      else store("egd-a11y-" + k, store("egd-a11y-" + k) === "1" ? "0" : "1");
      store("egd-a11y-scale", String(scale)); applyFlags();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !panel.hidden) { toggle(false); a11yBtn.focus(); } });
  }
  applyFlags();

  /* ---------- cookie consent ---------- */
  var bar = document.getElementById("cookieBar");
  function loadAnalytics() { /* add Google Analytics here once you have an ID; it only runs after "Accept all" */ }
  var choice = store("egd-cookies");
  if (choice === "all") loadAnalytics();
  if (bar && !choice) bar.hidden = false;
  if (bar) bar.addEventListener("click", function (e) {
    var b = e.target.closest("[data-cookie]"); if (!b) return;
    store("egd-cookies", b.dataset.cookie); bar.hidden = true;
    if (b.dataset.cookie === "all") loadAnalytics();
  });
  document.querySelectorAll("[data-cookie-settings]").forEach(function (a) {
    a.addEventListener("click", function (e) { e.preventDefault(); if (bar) bar.hidden = false; });
  });
})();
