# Experts Garage Doors – Wilmington, DE

Website for Experts Garage Doors, serving New Castle County, Delaware only.
Plain HTML, CSS and JavaScript. No build step needed.

## Put it on GitHub
1. Go to github.com → **New repository** → name it (for example `experts-garage-doors-wilmington`) → **Create repository**.
2. Click **uploading an existing file**.
3. Drag **everything inside this folder** (not the folder itself) into the page.
4. Click **Commit changes**.

## Publish with Cloudflare Pages
1. dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
2. Pick this repository.
3. Build settings: Framework preset **None**, build command **empty**, build output directory **/**.
4. **Save and Deploy**. Every change you commit to GitHub goes live by itself.
5. Project → **Custom domains** → add your domain and the `www.` version.

## Files
| File / folder | What it is |
|---|---|
| `index.html` | Home page |
| `garage-door-*.html`, `gate-*.html`, `commercial-*.html` | Service pages |
| `garage-door-repair-<town>-de.html` | Town pages |
| `useful-information.html` | Troubleshooting videos and warranty |
| `privacy-policy.html`, `404.html` | Privacy policy and "page not found" |
| `assets/` | Styles (`style.css`) and script (`site.js`) |
| `img/`, `media/` | Photos and videos |
| `sitemap.xml`, `robots.txt` | For Google. Submit the sitemap in Google Search Console |
| `_headers`, `_redirects` | Cloudflare speed and redirect settings |

## Things to set
- **Domain:** the pages use `https://www.expertsgarageddorswilmington.com`. If your domain is different, search-and-replace it in every `.html` file, `sitemap.xml` and `robots.txt`.
- **Estimate form:** in each page, find `data-endpoint=""` and put your Formspree link between the quotes.
- **Google Analytics:** add it inside `loadAnalytics()` in `assets/site.js`. It only runs after a visitor clicks "Accept all".
